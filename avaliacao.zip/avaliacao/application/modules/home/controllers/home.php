<?php if ( ! defined('BASEPATH')){exit('No direct script access allowed'); }
class Home extends MY_controller {

    public function __construct (){
        parent::__construct();
        $this->load->model('home_m');
        $this->autoLoadAssets();
    }

    public function index (){
        $list = $this->home_m->get();
        $this->template->set('pageTitle', 'Empresas - Sistema de Avaliação de Conhecimentos 2021')
                        ->set('list', $list)
                        ->build('home');
    }

    public function adicionar ()
    {
        $this->template->set('pageTitle', 'Empresas - Sistema de Avaliação de Conhecimentos 2021')
                        ->add_js($this->_basePlugins.'jquery.mask.js', 'comum')
                        ->set('states', $this->home_m->get_states())
                        ->build('form');
    }

    public function clientes ($id_company = FALSE)
    {
        if (!$id_company) {
            redirect('home');
        }

        $list = $this->home_m->get_clients($id_company);

        $this->template->set('pageTitle', 'Clientes - Sistema de Avaliação de Conhecimentos 2021')
                       ->set('list', $list)
                       ->set('id_company', $id_company)
                       ->build('list-clientes');
    }

    public function adicionar_cliente ($id_company = FALSE)
    {
        if (!$id_company) {
            redirect('home');
        }

        $this->template->set('pageTitle', 'Clientes - Sistema de Avaliação de Conhecimentos 2021')
                        ->add_js($this->_basePlugins.'jquery.mask.js', 'comum')
                        ->set('id_company', $id_company)
                        ->build('form-clientes');
    }

    public function add_numero()
    {
        $html = $this->load->view('numero', array() ,true);
        $return = array(
            'status' => TRUE,
            'html' => $html
        );
        $this->output->set_content_type('application/json')
                     ->set_output(json_encode($return));
    }

    public function company_client()
    {
        if (!$this->input->is_ajax_request())
            show_404();

        $data = $this->input->post();
        $this->load->library('form_validation');

        $this->form_validation->set_rules('name', 'Nome', 'trim|required');
        $this->form_validation->set_rules('email', 'E-mail', 'trim|required');
        $this->form_validation->set_rules('cep', 'CEP', 'trim|required');
        $this->form_validation->set_rules('rua', 'Rua', 'trim|required');
        $this->form_validation->set_rules('bairro', 'Bairro', 'trim|required');
        $this->form_validation->set_rules('cidade', 'Cidade', 'trim|required');
        $this->form_validation->set_rules('uf', 'UF', 'trim|required');
        $this->form_validation->set_rules('numero', 'Número', 'trim|required');

        if($data['pessoa'] == 'PJ'){
            $this->form_validation->set_rules('cnpj', 'CNPJ', 'trim|required');
        }else{
            $this->form_validation->set_rules('cpf', 'CPF', 'trim|required');
            $this->form_validation->set_rules('nascimento', 'Data Nascimento', 'trim|required');
            $this->form_validation->set_rules('rg', 'RG', 'trim|required');

            if($data['uf'] == 'PR'){
                $nascimento = explode('/', $data['nascimento']);
                $ano = end($nascimento);
                if((date('Y') - $ano) < 18){
                    $return = array(
                        'status' => FALSE,
                        'class' => 'error',
                        'message' => "Idade mínima 18 anos!"
                    );
                    $this->output->set_content_type('application/json')
                                ->set_output(json_encode($return));
                }
            }
        }

        if ($this->form_validation->run()) {
            $insert = array(
                'id_company' => $data['id_company'],
                'name' => $data['name'],
                'email' => $data['email'],
                'cep' => $data['cep'],
                'rua' => $data['rua'],
                'bairro' => $data['bairro'],
                'cidade' => $data['cidade'],
                'uf' => $data['uf'],
                'numero' => $data['numero'],
            );
            if ($data['pessoa'] == 'PJ') {
                $insert['cnpj'] = $data['cnpj'];
            } else {
                $insert['cpf'] = $data['cpf'];
                $insert['nascimento'] = date('Y-m-d', strtotime($data['nascimento']));
                $insert['rg'] = $data['rg'];
            }

            $response = $this->home_m->insert_client($insert, $data['phone']);

            if ($response) {
                $return = array(
                    'status' => TRUE,
                    'class' => 'success',
                    'url' => site_url('home/clientes/' . $data['id_company']),
                    'message' => "Cliente cadastrado com sucesso!"
                );
            } else {
                $return = array(
                    'status' => FALSE,
                    'class' => 'error',
                    'message' => $this->db->display_error()
                );
            }
        } else {
            $return = array(
                'status' => FALSE,
                'class' => 'error',
                'message' => validation_errors(),
                'fail' => $this->form_validation->error_array(TRUE)
            );
        }

        $this->output->set_content_type('application/json')
                    ->set_output(json_encode($return));
    }

    /** Lista as informações da empresa para edição */
    public function editar($id = FALSE)
    {
        // Caso ID vazio mostra tela 404
        if(!$id){
            show_404();
        }

        $list = $this->home_m->get($id);

        // Caso não encontre resultado mostra 404
        if (!$list) {
            show_404();
        }

        $this->template->set('pageTitle', 'Empresas - Sistema de Avaliação de Conhecimentos 2021')
                       ->add_js($this->_basePlugins . 'jquery.mask.js', 'comum')
                       ->set('states', $this->home_m->get_states())
                       ->set('list', $list)
                       ->build('form-edit');
    }

    /** Salva as informações da empresa */
    public function company_save()
    {
        if (!$this->input->is_ajax_request())
            show_404();

        $this->load->library('form_validation');
        $this->form_validation->set_rules('razao', 'Razão Social', 'trim|required');
        $this->form_validation->set_rules('cnpj', 'CNPJ', 'trim|required');
        $this->form_validation->set_rules('id_state', 'UF', 'trim|required');

        if ($this->form_validation->run()) {
            $data = $this->input->post();

            $response = $this->home_m->insert_company($data);

            if($response){
                $return = array(
                    'status' => TRUE,
                    'class' => 'success',
                    'url' => site_url('home'),
                    'message' => "Empresa inserida com sucesso!"
                );
            }else{
                $return = array(
                    'status' => FALSE,
                    'class' => 'error',
                    'message' => $this->db->display_error()
                );
            }
        }else{
            $return = array(
                'status' => FALSE,
                'class' => 'error',
                'message' => validation_errors(),
                'fail' => $this->form_validation->error_array(TRUE)
            );
        }

        $this->output->set_content_type('application/json')
                     ->set_output(json_encode($return));
    }

    /** Edita as informações da empresa */
    public function company_edit()
    {
        if (!$this->input->is_ajax_request())
            show_404();

        $this->load->library('form_validation');
        $this->form_validation->set_rules('razao', 'Razão Social', 'trim|required');
        $this->form_validation->set_rules('cnpj', 'CNPJ', 'trim|required');
        $this->form_validation->set_rules('id_state', 'UF', 'trim|required');

        if ($this->form_validation->run()) {
            $data = $this->input->post();

            $response = $this->home_m->edit_company($data);

            if ($response) {
                $return = array(
                    'status' => TRUE,
                    'class' => 'success',
                    'url' => site_url('home'),
                    'message' => "Empresa alterada com sucesso!"
                );
            } else {
                $return = array(
                    'status' => FALSE,
                    'class' => 'error',
                    'message' => $this->db->display_error()
                );
            }
        } else {
            $return = array(
                'status' => FALSE,
                'class' => 'error',
                'message' => validation_errors(),
                'fail' => $this->form_validation->error_array(TRUE)
            );
        }

        $this->output->set_content_type('application/json')
                    ->set_output(json_encode($return));
    }
}