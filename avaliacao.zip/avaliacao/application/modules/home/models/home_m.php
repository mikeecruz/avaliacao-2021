<?php if ( ! defined('BASEPATH')){exit('No direct script access allowed'); }

class Home_m extends MY_model {

    public function __construct (){
        parent::__construct();

    }

    public function get($id = null)
    {
        $this->db->select("company.*")
            ->from("company")
            ->group_by("company.id")
            ->order_by("company.id", "DESC");

        if($id){
            $this->db->where("company.id", $id);
        }

        $query = $this->db->get();
        return $query->result();
    }

    public function get_clients($id = null)
    {
        $this->db->select("clients.*")
                ->from("clients")
                ->where("clients.id_company", $id)
                ->order_by("clients.id", "DESC");

        $query = $this->db->get();
        return $query->result();
    }

    public function get_states()
    {
        $this->db->select("state.*")
                 ->from("state")
                 ->group_by("state.id")
                 ->order_by("state.name", "ASC");

        $query = $this->db->get();
        return $query->result();
    }

    public function insert_company($data)
    {
        $this->db->trans_start();
        $this->db->insert('company', $data);
        $this->db->trans_complete();
        return $this->db->trans_status();
    }

    public function edit_company($data)
    {
        $this->db->trans_start();
        $this->db->where('id', $data['id'])
                 ->update('company', array('razao' => $data['razao'], 'cnpj' => $data['cnpj'], 'id_state' => $data['id_state']));
        $this->db->trans_complete();
        return $this->db->trans_status();
    }

    public function insert_client($data, $phones)
    {
        $this->db->trans_start();
        $this->db->insert('clients', $data);

        $id = $this->db->insert_id();

        foreach ($phones as $phone) {
            $this->db->insert('clients_phones', array('id_client' => $id, 'phone' => $phone));
        }

        $this->db->trans_complete();
        return $this->db->trans_status();
    }
}