/**
 * js
 *
 * @subpackage home
 * @category js
 * @author Michael Cruz
 * @copyright 2021
 */

"use strict";
function Home() {
    this.init();
};

Home.prototype.init = function () {
    var self = this;
    self.save();
    self.busca_cep();
    self.change_radio();

    if ($(".cnpj").length) {
        $('.cnpj').mask('00.000.000/0000-00');
    };

    if ($(".cpf").length) {
        $('.cpf').mask('000.000.000-00');
    };

    if ($(".data").length) {
        $('.data').mask('00/00/0000');
    };

    if ($(".cep").length) {
        $('.cep').mask('00000-000');
    };

    if ($(".phone").length) {
        $('.phone').mask('(00) 0000-00000');
    };

    if ($(".cpfcnpj").length) {
        var options = {
            onKeyPress: function (cpf, ev, el, op) {
                var masks = ['000.000.000-000', '00.000.000/0000-00'];
                $('.cpfcnpj').mask((cpf.length > 14) ? masks[1] : masks[0], op);
            }
        }

        if($('.cpfcnpj').length > 11) {
            $('.cpfcnpj').mask('00.000.000/0000-00', options)
        }else{
            $('.cpfcnpj').mask('000.000.000-00#', options);
        }
    };

    $('.select2').select2();

    $("#add-numero").on("click", function(){
        $.ajax({
            url: siteUrl + 'home/add_numero',
            type: 'html',
            success: function (response) {
                $(".cont-telefone").append(response.html);
            }
        });
    });
};

Home.prototype.change_radio = function () {
    setTimeout(() => {
        $('input[name="cpf"], input[name="nascimento"], input[name="rg"]').hide().attr("required", false);
        $('input[name="cnpj"]').show().attr("required", true);
    }, 300);

    $('input[type="radio"]').on("change", function(e){
        if ($(this).val() == "PJ"){
            $('input[name="cpf"], input[name="nascimento"], input[name="rg"]').hide().attr("required", false);
            $('input[name="cnpj"]').show().attr("required", true);
        }else{
            $('input[name="cpf"], input[name="nascimento"], input[name="rg"]').show().attr("required", true);
            $('input[name="cnpj"]').hide().attr("required", false);
        }
    }).change();
}

Home.prototype.busca_cep = function() {
    var self = this;

    $("#cep").blur(function () {
        var cep = $(this).val().replace(/\D/g, '');
        if (cep != "") {
            var validacep = /^[0-9]{8}$/;
            if (validacep.test(cep)) {
                $("#rua").val("...");
                $("#bairro").val("...");
                $("#cidade").val("...");
                $("#uf").val("...");
                $.getJSON("https://viacep.com.br/ws/" + cep + "/json/?callback=?", function (dados) {
                    if (!("erro" in dados)) {
                        $("#rua").val(dados.logradouro);
                        $("#bairro").val(dados.bairro);
                        $("#cidade").val(dados.localidade);
                        $("#uf").val(dados.uf);
                    }else {
                        self.limpa_cep();
                        Swal.fire({
                            title: 'Atenção!',
                            text: "CEP não encontrado.",
                            icon: "error",
                            showConfirmButton: false,
                            timer: 1500,
                        });
                    }
                });
            }else {
                self.limpa_cep();
                Swal.fire({
                    title: 'Atenção!',
                    text: "Formato de CEP inválido.",
                    icon: "error",
                    showConfirmButton: false,
                    timer: 1500,
                });
            }
        }else {
            self.limpa_cep();
        }
    });
}

Home.prototype.limpa_cep = function () {
    var self = this;
    $("#rua").val("");
    $("#bairro").val("");
    $("#cidade").val("");
    $("#uf").val("");
}

Home.prototype.save = function () {
    var self = this;
    $('form.form-company').validate({
        errorPlacement: function (e, ee) {
            return false;
        },
        submitHandler: function (form) {
            if ($(form).hasClass('loading'))
                return false;
            $(form).addClass('loading');
            $.ajax({
                url: $(form).attr('action'),
                dataType: 'JSON',
                type: 'POST',
                data: $(form).serialize(),
                success: function (response) {
                    Swal.fire({
                        title: '',
                        text: response.message,
                        icon: response.class,
                        showConfirmButton: false,
                        timer: 1500,
                    });
                    if (response.status) {
                        $(form).find('input').val('');
                        setTimeout(() => {
                            window.location = response.url;
                        }, 1600);
                    }
                }
            });
        }
    });
}

$(document).ready(function () {
    new Home();
});