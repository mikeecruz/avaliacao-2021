<section id="list">
    <div class="common-limiter">
        <h1>Lista de Empresas</h1>
        <div class="middle">
            <a href="<?php echo site_url('home/adicionar'); ?>" class="btn-insert">Adicionar</a>
            <?php
            if ($list) {
                foreach ($list as $each_list) { ?>
                    <div class="row">
                        <div class="col-name"><?php echo $each_list->razao; ?> - <?php echo $each_list->cnpj; ?></div>
                        <div class="col-action">
                            <a href="<?php echo site_url('home/clientes/'. $each_list->id); ?>" class="btn-action">Clientes</a>
                            <a href="<?php echo site_url('home/editar/' . $each_list->id); ?>" class="btn-action">Editar</a>
                        </div>
                    </div>
                <?php }
            } else { ?>
                <h2>Nenhuma empresa cadastrada</h2>
            <?php } ?>
        </div>
    </div>
</section>