<section id="list">
    <div class="common-limiter">
        <h1>Lista de Clientes</h1>
        <div class="middle">
            <a href="<?php echo site_url('home/adicionar-cliente/'. $id_company); ?>" class="btn-insert">Adicionar</a>
            <?php
            if ($list) {
                foreach ($list as $each_list) { ?>
                    <div class="row">
                        <div class="col-name"><?php echo $each_list->name; ?> - <?php echo ($each_list->cnpj ? $each_list->cnpj : $each_list->cpf); ?></div>
                    </div>
                <?php }
            } else { ?>
                <h2>Nenhum cliente cadastrado</h2>
            <?php } ?>
        </div>
    </div>
</section>