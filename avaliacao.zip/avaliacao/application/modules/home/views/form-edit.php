<section id="form">
    <div class="common-limiter">
        <h1>Cadastro de Empresa</h1>
        <form action="<?php echo site_url('home/company_edit'); ?>" novalidate method="POST" class="form form-company">
            <div class="row-form">
                <input name="razao" type="text" placeholder="Razão Social*" value="<?php echo $list[0]->razao; ?>" class="input" required>
            </div>
            <div class="row-form">
                <input name="cnpj" type="text" placeholder="CNPJ*" value="<?php echo $list[0]->cnpj; ?>" class="input cnpj" required>
            </div>
            <div class="row-form">
                <select name="id_state" class="select2" required>
                    <option value="" selected disabled>UF*</option>
                    <?php foreach ($states as $each_states) { ?>
                        <option <?php echo ($list[0]->id_state == $each_states->id) ? 'selected' : ''; ?> value="<?php echo $each_states->id; ?>"><?php echo $each_states->name . ' - ' . $each_states->uf; ?></option>
                    <?php } ?>
                </select>
            </div>
            <input type="hidden" name="id" value="<?php echo $list[0]->id; ?>">
            <button type="submit">Salvar</button>
            <a href="<?php echo site_url('home'); ?>">Voltar</a>
        </form>
    </div>
</section>