<section id="form">
    <div class="common-limiter">
        <h1>Cadastro de Cliente</h1>
        <form action="<?php echo site_url('home/company_client'); ?>" novalidate method="POST" class="form form-company">
            <div class="row-form">
                <input name="name" type="text" placeholder="Nome*" class="input" required>
            </div>

            <label class="container">PJ
                <input type="radio" name="pessoa" checked value="PJ">
                <span class="checkmark"></span>
            </label>

            <label class="container">PF
                <input type="radio" name="pessoa" value="PF">
                <span class="checkmark"></span>
            </label>

            <div class="row-form">
                <input name="cnpj" type="text" placeholder="CNPJ*" class="input cnpj" required>
            </div>

            <div class="row-form">
                <input name="cpf" type="text" placeholder="CPF*" class="input cpf" required>
            </div>

            <div class="row-form">
                <input name="nascimento" type="text" placeholder="Data Nascimento*" class="input data" required>
            </div>

            <div class="row-form">
                <input name="rg" type="text" placeholder="RG*" class="input" required>
            </div>


            <div class="row-form">
                <input name="email" type="email" placeholder="E-mail*" class="input" required>
            </div>

            <div class="row-form">
                <input name="cep" id="cep" type="text" placeholder="CEP*" class="input cep" required>
            </div>

            <div class="row-form">
                <input name="rua" id="rua" type="text" placeholder="Rua*" class="input readonly" required readonly>
            </div>

            <div class="row-form">
                <input name="bairro" id="bairro" type="text" placeholder="Bairro*" class="input readonly" required readonly>
            </div>

            <div class="row-form">
                <input name="cidade" id="cidade" type="text" placeholder="Cidade*" class="input readonly" required readonly>
            </div>

            <div class="row-form">
                <input name="uf" id="uf" type="text" placeholder="UF*" class="input readonly" required readonly>
            </div>

            <div class="row-form">
                <input name="numero" id="numero" type="text" placeholder="Número*" class="input" required>
            </div>

            <div class="cont-telefone">
                <div class="row-form">
                    <input name="phone[]" type="text" placeholder="Telefone*" class="input phone" required>
                </div>
                <button type="button" id="add-numero">Adicionar número</button>
            </div>

            <input type="hidden" name="id_company" value="<?php echo $id_company ?>">
            <button type="submit">Salvar</button>
            <a href="<?php echo site_url('home/clientes/'. $id_company); ?>">Voltar</a>
        </form>
    </div>
</section>