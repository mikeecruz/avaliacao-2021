<div class="row-form">
    <input name="phone[]" type="text" placeholder="Telefone*" class="input phone" required>
</div>