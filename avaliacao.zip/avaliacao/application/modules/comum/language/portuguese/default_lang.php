<?php
$lang['site'] = '';