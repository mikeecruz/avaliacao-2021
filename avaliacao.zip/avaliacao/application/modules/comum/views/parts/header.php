<section id="header">
    <div class="common-limiter">
        <a id="logo" alt="Avaliação de Conhecimentos" title="Avaliação de Conhecimentos" href="<?php echo site_url('home'); ?>">
            <img class="logo" src="<?php echo $_siteUrls["baseImg"] . 'logo.png'; ?>" alt="Avaliação de Conhecimentos">
        </a>
        <nav>
            <h1>Avaliação de Conhecimentos</h1>
        </nav>
    </div>
</section>