<?php if ( ! defined('BASEPATH')){exit('No direct script access allowed'); }

class comum_m extends MY_model {
    public function __construct()
    {
        parent::__construct();
    }
}